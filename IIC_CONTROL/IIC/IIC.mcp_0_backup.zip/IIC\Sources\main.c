#include <hidef.h> /* for EnableInterrupts macro */
#include "derivative.h" /* include peripheral declarations */
#define setReg8(x,y) (x=y)
#define IIC_RepeatStart() IICC1_RSTA=1

void IIC1_Init(void);
void InitClock(void);

void delay(void);
void interrupt VectorNumber_Viic IIC(void);
void IIC_write_byte(byte);
byte IIC_read_byte(void);
void IIC_Start(void);
void IIC_Stop(void);
void configIIC(void);

int timeout,error;
byte iic1=0,iic2=0;

void main(void) {

  EnableInterrupts; /* enable interrupts */
  /* include your code here */
  InitClock();
  IIC1_Init();
  configIIC();
  
  IIC_Start();
  IIC_write_byte(0x3D);
  IIC_write_byte(0x03);
  iic1=IIC_read_byte();
  
  for(;;) {
  
 
    __RESET_WATCHDOG(); /* feeds the dog */
  } /* loop forever */
  /* please make sure that you never leave main */
}





void interrupt VectorNumber_Viic IIC(void){
(void)IICS;
IICS_IICIF=1;  
  
  
}
  
  

  
void delay (void){
  unsigned int t=30000;
  while(t!=0){
  t--;
  }
}





void configIIC(void){
  IIC_Start();
  IIC_write_byte(0x3C);
  IIC_write_byte(0x02);
  IIC_write_byte(0x00);
  IIC_Stop();
  
}





void IIC_write_byte(byte data)
{
 
 //-------start of transmit first byte to IIC bus-----
 IICD = data;
 while (!IICS_IICIF); // wait until IBIF;
 IICS_IICIF=1; // clear the interrupt event flag;
 while(IICS_RXAK); // check for RXAK;
 //-----Slave ACK occurred------------
 
 
}

void IIC_Start(void){
 IICC1_TX=1;
 IICC1_TXAK = 0; // RX/TX = 1; MS/SL = 1; TXAK = 0;
 IICC1 |= 0x30; // And generate START condition;
}

void IIC_Stop(void){
  IICC1_MST = 0; // generate STOP condition;
}
  


byte IIC_read_byte(void)
{
 
 Byte RD_data;
 IICC1_TX = 0; // set up to receive;
 IICC1_TXAK = 1; // acknowledge disable;
 RD_data = IICD; // dummy read;
 while (!IICS_IICIF); // wait until IBIF;
 IICS_IICIF=1; // clear the interrupt event flag;
 RD_data = IICD; // read right data;
 return RD_data;
}

void IIC1_Init(void)
{
                              
  /* IICF: MULT1=0,MULT0=1,ICR5=0,ICR4=0,ICR3=0,ICR2=0,ICR1=0,ICR0=0 */
  setReg8(IICF, 0x40);
  /* IICC2: GCAEN=0,ADEXT=0,??=0,??=0,??=0,AD10=0,AD9=0,AD8=0 */
  setReg8(IICC2, 0x00);              
  
  /* IICC1: IICEN=1,IICIE=1,MST=0,TX=0,TXAK=0,RSTA=0,??=0,??=0 */
  setReg8(IICC1, 0xC0);
  /* IICS: TCF=1,IAAS=0,BUSY=0,ARBL=1,??=0,SRW=0,IICIF=1,RXAK=0 */
  setReg8(IICS, 0x92);                 /* Clear the interrupt flags */                    
}

void InitClock(void){
  /* ### MC9S08SH8_24 "Cpu" init code ... */
  /*  PE initialization code after reset */

  /* Common initialization of the write once registers */
  /* SOPT1: COPT=0,STOPE=0,??=0,??=0,IICPS=0,BKGDPE=1,RSTPE=0 */
  setReg8(SOPT1, 0x02);                 
  /* SPMSC1: LVWF=0,LVWACK=0,LVWIE=0,LVDRE=1,LVDSE=1,LVDE=1,??=0,BGBE=0 */
  setReg8(SPMSC1, 0x1C);                
  /* SPMSC2: ??=0,??=0,LVDV=0,LVWV=0,PPDF=0,PPDACK=0,??=0,PPDC=0 */
  setReg8(SPMSC2, 0x00);                
  /*  System clock initialization */
  if (*(unsigned char*)0xFFAF != 0xFF) { /* Test if the device trim value is stored on the specified address */
    ICSTRM = *(unsigned char*)0xFFAF;  /* Initialize ICSTRM register from a non volatile memory */
    ICSSC = *(unsigned char*)0xFFAE;   /* Initialize ICSSC register from a non volatile memory */
  }
  /* ICSC1: CLKS=0,RDIV=0,IREFS=1,IRCLKEN=1,IREFSTEN=0 */
  setReg8(ICSC1, 0x06);                /* Initialization of the ICS control register 1 */ 
  /* ICSC2: BDIV=0,RANGE=0,HGO=0,LP=0,EREFS=0,ERCLKEN=0,EREFSTEN=0 */
  setReg8(ICSC2, 0x00);                /* Initialization of the ICS control register 2 */ 
  while(!ICSSC_IREFST) {               /* Wait until the source of reference clock is internal clock */
  }
  /* GNGC: GNGPS7=0,GNGPS6=0,GNGPS5=0,GNGPS4=0,GNGPS3=0,GNGPS2=0,GNGPS1=0,GNGEN=0 */
  setReg8(GNGC, 0x00);                  
  /*** End of PE initialization code after reset ***/
  
  
}

