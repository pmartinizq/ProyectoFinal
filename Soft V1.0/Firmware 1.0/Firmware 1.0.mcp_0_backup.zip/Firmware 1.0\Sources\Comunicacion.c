#include "Comunicacion.h"
/**
@brief Envia una trama de datos por el puerto serial obtenida por el buffer de salida

*/

void SendData(void){
  
  
  
  
 return; 
}

