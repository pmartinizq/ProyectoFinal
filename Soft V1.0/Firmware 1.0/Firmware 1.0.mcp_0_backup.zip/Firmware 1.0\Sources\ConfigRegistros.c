#ifndef _ConfigRegistros_h
#define _ConfigRegistros_h
#include <hidef.h> /* for EnableInterrupts macro */
#include "derivative.h" /* include peripheral declarations */



#define uint8_t byte


#endif