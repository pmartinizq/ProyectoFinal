
#include "Config.h"



void main(void) {

  
  int t;
  /* include your code here */
  
  f1.functionId=0x01;
  f1.status=READY;
  f1.root=UNIQUE_FUNCTION;
  f1.timerCount=50;
  
  DisableInterrupts;
  InitReg();  
  InitClock();
  InitComunication();
  InitInputCompare();
  InitPorts();
  InitRtc();
  beginComunication();
  initExecutingVector();
  InitBuffer(&bufferIn);
  InitBuffer(&bufferOut);
  EnableInterrupts;
  
  
  for(;;) {
  
  functionHandler();
  dispatcher(&executingVector,&bufferOut);
  frameGenerator();
    
    /*Sensor1(&f1);
    
    while(f1.status!=AVAILABLE);
    t=30000;
    while(t!=0){
      t--;
    } */
    
  } /* loop forever */
  /* please make sure that you never leave main */
}
