#include "Config.h"


#ifndef _Dispatcher_h
#define _Dispatcher_h
#endif

void dispatcher(ExecutingStruct* executingVector, BufferStruct* functionBuffer);
