#include "API.h"

int* GetMeassure(uint8_t TYPE){
	
	Send(START_BYTE);
	Send(GETMEASSURE);
	Send(TYPE);
	
	volatile uint8_t getMeassureVariable = 0;
	
	getMeassureVariable = Get();
	if(getMeassureVariable == START_BYTE){
		getMeassureVariable = Get();
		if(getMeassureVariable == GETMEASSURE){
			if(TYPE == ULTRASONIC_ALL){
				counter = Get();
				for(auxCounter = 0; auxCounter < counter; auxCounter++){
					result[auxCounter] = Get();
				}
			}
			else if(TYPE == ACCEL || TYPE == GYRO || TYPE == COMPASS){
				counter = Get();
				for(auxCounter = 0; auxCounter < counter/2; auxCounter++){
					auxConverter1 = Get();
					auxConverter2 = Get();
					result[auxCounter] = (auxConverter1 << 8);
					result[auxCounter] = result[auxCounter] + auxConverter2;
				}
			}
			else if(TYPE == ULTRASONIC_FRONT || TYPE == ULTRASONIC_LEFT || TYPE == ULTRASONIC_RIGHT){
				result[0] = Get();
			}
			else{
				ErrorPrint("GETMEASSURE","INVALID PARAMETER");
				result[0] = 0;
			}
		}
		else{
			if(getMeassureVariable == ERROR){
				getMeassureVariable = Get();
				if(getMeassureVariable == 2){
					getMeassureVariable = Get();
					if(getMeassureVariable == GETMEASSURE){
						getMeassureVariable = Get();
						ErrorPrint("GETMEASSURE",getMeassureVariable);
					}
				}
		}	
		}
	}
	else{
		ErrorPrint("GETMEASSURE","INVALID FUNCTION RECIVED");
		result[0] = 0;
	}
	return result;
}

bool SetVelocity(int leftWheelVelocity, int rightWheelVelocity){
	Send(START_BYTE);
	Send(SETVELOCITY);
	Send(4);
	Send((uint8_t)(leftWheelVelocity >> 8));
	Send((uint8_t)(leftWheelVelocity ));
	Send((uint8_t)(rightWheelVelocity >> 8));
	Send((uint8_t)(rightWheelVelocity));
	boolResult = FALSE;
	variable = Get();
	if(variable == START_BYTE){
		variable = Get();
		if(variable == ACK){
			variable = Get();
			if(variable == SETVELOCITY){
				boolResult = TRUE;
			}
		}
		else{
			if(variable == ERROR){
				variable = Get();
				if(variable == 2){
					variable = Get();
					if(variable == SETVELOCITY){
						variable = Get();
						ErrorPrint("SETVELOCITY",variable);
					}
				}
			}
		}
	}
	else{
		ErrorPrint("SETVELOCITY","INVALID FUNCTION RECIVED");
		boolResult = FALSE;
	}
	return boolResult;
}

/*


bool SetVelocity(uint16_t leftWheelVelocity, uint16_t rightWheelVelocity){
	Send(START_BYTE);
	Send(SETVELOCITY);
	Send(4);
	Send((leftWheelVelocity & 0XFF));
	Send((leftWheelVelocity >> 8));
	Send((rightWheelVelocity & 0XFF));
	Send((rightWheelVelocity >> 8));
	boolResult = FALSE;
	variable = Get();
	if(variable == START_BYTE){
		variable = Get();
		if(variable == ACK){
			variable = Get();
			if(variable == SETVELOCITY){
				boolResult = TRUE;
			}
		}
		else{
			if(variable == ERROR){
				variable = Get();
				if(variable == 2){
					variable = Get();
					if(variable == SETVELOCITY){
						variable = Get();
						ErrorPrint("SETVELOCITY",variable);
					}
				}
			}
		}
	}
	return boolResult;
}*/
bool SetSteps(int leftWheelSteps, int rightWheelSteps){
	Send(START_BYTE);
	Send(SETSTEPS);
	Send(4);
	Send((uint8_t)(leftWheelSteps >> 8));
	Send((uint8_t)(leftWheelSteps ));
	Send((uint8_t)(rightWheelSteps >> 8));
	Send((uint8_t)(rightWheelSteps));
	boolResult = FALSE;
	variable = Get();
	if(variable == START_BYTE){
		variable = Get();
		if(variable == ACK){
			variable = Get();
			if(variable == SETSTEPS){
				boolResult = TRUE;
			}
		}
		else{
			if(variable == ERROR){
				variable = Get();
				if(variable == 2){
					variable = Get();
					if(variable == SETSTEPS){
						variable = Get();
						ErrorPrint("SETSTEPS",variable);
					}
				}
			}
		}
	}
	else{
		ErrorPrint("SETSTEPS","INVALID FUNCTION RECIVED");
		boolResult = FALSE;
	}
	return boolResult;
}

bool IsGoal(uint8_t MODE){
	Send(START_BYTE);
	Send(ISGOAL);
	Send(MODE);
	boolResult = FALSE;
	variable = Get();
	if(variable == START_BYTE){
		variable = Get();
		if(variable == ISGOAL){
			variable = Get();
			if(variable == ISGOAL_TRUE){
				boolResult = TRUE;
			}	
		}
		else{
			if(variable == ERROR){
				variable = Get();
				if(variable == 2){
					variable = Get();
					if(variable == SETSTEPS){
						variable = Get();
						ErrorPrint("ISGOAL",variable);
					}
				}
			}
		}
	}
	else{
		ErrorPrint("ISGOAL","INVALID FUNCTION RECIVED");
		boolResult = FALSE;
	}
	return boolResult;

}


