#ifndef _API_H_
#define _API_H_

#include "stdint.h"
#include "stdlib.h"

#define bool uint8_t
#define TRUE 1
#define FALSE 0

#define START_BYTE 0xAA

#define GETMEASSURE 0x01
#define GETMEASSURE_RESPONSE 0x82
#define SETVELOCITY 0x81
#define SETSTEPS 0x80
#define ISGOAL 0x02
#define ACK 0x06
#define ERROR 0x85

#define ULTRASONIC_RIGHT 9 
#define ULTRASONIC_LEFT 8
#define ULTRASONIC_FRONT 10
#define ULTRASONIC_ALL 7
#define ACCEL 11
#define GYRO 12
#define COMPASS 13

#define STOP_ON_GOAL 14
#define CONTINUE 15
#define NOP 16
#define ISGOAL_TRUE 1
#define ISGOAL_FALSE 0

uint8_t variable;
uint8_t counter;
uint8_t auxCounter;
uint8_t auxConverter1;
uint8_t auxConverter2;
int result[12];
bool boolResult;

#ifdef __cplusplus
extern "C" {
#endif

int* GetMeassure(uint8_t TYPE);

bool SetVelocity(int leftWheelVelocity, int rightWheelVelocity);

bool SetSteps(int leftWheelSteps, int rightWheelSteps);

bool IsGoal(uint8_t MODE);

void Send(uint8_t DATA);

uint8_t Get();

void ErrorPrint(char function[], uint8_t var);

#ifdef __cplusplus
}
#endif

#endif